import logging
from aiogram import Bot, Dispatcher

bot = Bot(token = '1142223769:AAFp9brL9aqbaqSRt8kUVPKqnbD0OCa5Ut4')
dp = Dispatcher(bot)
logging.basicConfig(level=logging.INFO)
